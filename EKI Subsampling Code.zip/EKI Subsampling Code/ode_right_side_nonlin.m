function [dUdt]=ode_right_side_nonlin(t,U,G,d,J,y,Gamma,beta,N_sub)

%Reshape into matrix form
U=reshape(U,[d,J]);
Y=repmat(y,1,J);

%Compute variables for ODE (RHS)
Gu=G(U);
Fu=[Gu;sqrt(beta)*U];
Fu_mean = mean(Fu,2);
U_mean = mean(U,2);
C_0 = eye(d);
Gamma_reg = blkdiag(Gamma,C_0);
z=[Y;zeros(d,J)];

%Covariance matrix
C_uG = (1/(J-1))*(U-U_mean)*(Fu-Fu_mean)';

%ODE formula
dUdt=-1/N_sub*C_uG*(Gamma_reg\(Fu-z));

%Reshape matrix into vector form
dUdt=dUdt(:);

end



