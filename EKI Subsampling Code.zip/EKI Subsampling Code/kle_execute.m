%Function to determine initial ensemble

function [u] = kle_execute(xi,Z1,Z2,meanfield,alpha,tau)
    [I,J] = size(xi);
    u = zeros(size(Z1,1)*size(Z1,2),J);
    K = sqrt(length(xi(:,1)));
    for j=1:J
        xi_j = reshape(xi(:,j),K,K);
        uu = KL_expansion(Z1,Z2,xi_j,meanfield,tau,alpha);
        u(:,j) = uu(:);
    end
end