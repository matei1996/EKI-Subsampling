function [jumptimes, batch] = subsamplebatch(t_0,T,J,N_sub,single)
% Function for continuous time markov process with uniform jumping times 
jumptimes=linspace(t_0,T,10000); %amount of changin times
x=1:N_sub; %batches
jumptimes(1)=[];

%Single subsampling only needs one batch for each changing times for all
%particles
if single==1
    batch=zeros(length(jumptimes)-1,1);
    batch(1)=randi([1 N_sub],1,1);

    if N_sub==1
        batch=ones(1,length(jumptimes));
    else
        for k=1:length(jumptimes)-1
            x_new=x;
            x_new(batch(k))=[];
            batch(k+1)=x_new(randi(numel(x_new)));
        end
        batch=batch';
    end

else
%Batch subsampling needs batches for each changing times for all
%particles
    if N_sub==1
        batch=ones(length(jumptimes),J);
    else
        
    batch=zeros(length(jumptimes),J);
    batch(1,:)=randi(N_sub,[1,J]);
        for k=1:length(jumptimes)-1
            for j=1:J
                x_new=x;
                x_new(batch(k,j))=[];
                batch(k+1,j)=x_new(randi(numel(x_new)));
            end
        end
        
    end

end
end

