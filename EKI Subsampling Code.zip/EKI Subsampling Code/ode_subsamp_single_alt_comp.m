function dUdt = ode_subsamp_single_alt_comp(t,U,G,d,J,y,Gamma,N_sub,alpha,beta,E_0)
%Right hand side of ODE with different batch for each particle

%Reshape into matrix Notation
U_inter=reshape(U,[d,J]);

%Compute covariance matrix
U_mean = mean(U_inter,2);
C_u = (1/(J-1))*(U_inter-U_mean)*(U_inter-U_mean)';

%Compact notation
C_u_comp=kron(eye(J),C_u);
E_0_comp=kron(eye(J),E_0'*E_0);

dUdt=(C_u_comp+alpha/(1+t)*eye(d*J))*(G'*(Gamma\(y-G*U))-beta/N_sub*E_0_comp*U);


end




