function [jumptimes, batch] = subsamplelinear(a,b,T,N_sub)
% Function for continuous time markov process with linear decaying learning
% rate (at+b)^-1 and same batch for each particle

%Determine times by inverse transformation formula
    batch(1)=randi([1 N_sub],1,1);
    t_0=0;
    jumptimes(1)=t_0;
    x=1:N_sub;
    k=1;
    if N_sub==1
        while t_0<T
          y=rand;
          t=(-a*t_0-b+sqrt((a*t_0+b)^2-2*a*log(1-y)))/a;
          t_0=t_0+t;
          jumptimes(k+1)=t_0;
          k=k+1;
        end
        batch=ones(1,length(jumptimes));
    else
        while t_0<T
            x_new=x;
            y=rand;
            t=(-a*t_0-b+sqrt((a*t_0+b)^2-2*a*log(1-y)))/a;
            x_new(batch(k))=[];
            batch(k+1)=x_new(randi(numel(x_new)));
            t_0=t_0+t;
            jumptimes(k+1)=t_0;
            k=k+1;
        end
    end
    jumptimes(end)=T;
    batch(end)=[];
end

