%Apply EKI/Subsampling for nonlinear 2D-darcy flow;
%we consider here EKI for the parameters


clearvars;

% Fixed paramters for heat equation code
% timestepping/finite differences parameters

%!!! Script 'gen_nonlin_darcy_params.m' needs to be executed first!!!

% Load parameters for Darcy Flow and for initialisation of the EKI
load('EKI_Darcy_nonlin_params.mat');

%Preallocation of different error values computed
est_err=zeros(length(tspan_alt),rep);
est_err_sol=zeros(length(tspan_alt),rep);
est_err_ss=zeros(length(jumptimes),rep);
est_err_ss_param=zeros(length(jumptimes),rep);

%Define Potentail and set options for optimisation
%We use the optimisation solution as reference solution
fun = @(u) (1/2)*norm((sqrtm(Gamma))\(G(u)-y))^2+(beta/2)*norm((sqrtm(C_0))\u)^2;
options = optimoptions(@fmincon,'MaxFunctionEvaluations',10^8,'Algorithm','sqp','MaxIterations',100);%,'Display','iter');


parfor i=1:rep
    
tic;
% we estimate coefficients of KL expansion
% set groundtruth
coef_0 = mvnrnd(zeros(I_c,1),C0,J)';
u_0 = u_kle(coef_0); %initial ensemble

%Generate Basis
u_0_bar=mean(u_0,2);
e_0=u_0-u_0_bar; %center particles
[R,basiccol]=rref(e_0); %determine linear independent ensembles
%E_0=e_0;
E_0=u_0(:,basiccol);

%Projection onto subspace; needed for optimisation
P_E=E_0*((E_0'*E_0)\(E_0'));
u_sub_orth=u_0_bar-P_E*u_0_bar;


%Single subsampling
U_single_sub=zeros(d,J,length(jumptimes));
U_single_sub(:,:,1)=u_0;


for j=1:(length(jumptimes)-1)

%solve ode over time intervals given by jumptimes
u_start=U_single_sub(:,:,j);
tspan=[jumptimes(j),(jumptimes(j)+jumptimes(j+1))/2,jumptimes(j+1)];

%Determine which subset we use and choose corresonding operator
r=randi([1 N_sub],1,1);
G_sample = @(utr) O_sub(:,:,r)*G(utr);


%Solve ODE
[time,U_sub]=ode45(@(t,U) ode_right_side_nonlin(t,U,G_sample,d,J,y_sample(:,r),Gamma_sample(:,:,r),beta,N_sub),tspan,u_start(:),opts);
U_sub=reshape(U_sub.',d,J,[]);
U_single_sub(:,:,j+1)=U_sub(:,:,3);

end

fprintf(' Single Subsampling: ')
toc;
%Solve Eki
tic;
[t,U_long]=ode45(@(t,U) ode_right_side_nonlin(t,U,G,d,J,y,Gamma,beta,1),tspan_alt,u_0(:),opts);
U_long=reshape(U_long.',d,J,[]);
fprintf(' EKI: ')
toc;

%Solve optimisation problem
[reg_data_missfit,fval] = fmincon(fun,mean(u_0,2),[],[],(eye(d)-P_E),u_sub_orth,[],[],[],options); 
%Save results
parsave(sprintf('NumericsNonLin/output%d.mat', i), U_long, U_single_sub, reg_data_missfit,fval);

end

%Load results and compute error values
for i=1:rep
%parload(sprintf('NumericsNonLin/output%d.mat', i), U_long, U_single_sub);
load(sprintf('NumericsNonLin/output%d.mat', i));
U_long=x;
U_single_sub=y;
reg_data_missfit=z;
fval=v;
     for m=1:L
         est_err(m,i) = (fun(mean(U_long(:,:,m),2))-fval);%/norm(fval);
         est_err_sol(m,i)=norm(mean(U_long(:,:,m),2)-reg_data_missfit);%/norm(reg_data_missfit);
     end


     for d=1:L_sub
      est_err_ss(d,i)=(fun(mean(U_single_sub(:,:,d),2))-fval);%/norm(fval);
      est_err_ss_param(d,i)=norm(mean(U_single_sub(:,:,d),2)-reg_data_missfit);%/norm(reg_data_missfit);
     end 
clearvars U_long U_single_sub reg_data_missfit fval x y z v
end

%Ensemble collapse
est_err_ek = zeros(length(tspan_alt),J,rep);
est_err_ek_sub = zeros(length(jumptimes),J,rep);

for i=1:rep
load(sprintf('NumericsNonLin/output%d.mat', i));
U_long=x;
U_single_sub=y;
 for m=1:L
     for j=1:J
     est_err_ek(m,j,i)=norm(U_long(:,j,m)-mean(U_long(:,:,m),2));
     end
 end


 for d=1:L_sub
     for j=1:J
     est_err_ek_sub(d,j,i)=norm(U_single_sub(:,j,d)-mean(U_single_sub(:,:,d),2));
     end
 end
 clearvars U_long U_single_sub x y z v
end

%Take the mean ensemble collapse over all runs
ek_eki=mean(est_err_ek,3);
ek_ss=mean(est_err_ek_sub,3);


%Plot results
fig4 = figure(4);
hold on
grid on
set(gca, 'YScale', 'log')
set(gca, 'XScale', 'log')
plot(tspan_alt,mean(est_err,2),'Color',[204 37 41]./255,'LineWidth',2)
plot(jumptimes,mean(est_err_ss,2),'Color',[57 106 177]./255,'LineWidth',2)
%plot(tspan_alt,mean(est_err,2)+std(est_err_sol,0,2),':','Color',[204 37 41]./255,'LineWidth',2)
%plot(tspan_alt,mean(est_err,2)-std(est_err_sol,0,2),':','Color',[204 37 41]./255,'LineWidth',2)
%plot(jumptimes,mean(est_err_ss,2)+std(est_err_ss,0,2),':','Color',[57 106 177]./255,'LineWidth',2)
%plot(jumptimes,mean(est_err_ss,2)-std(est_err_ss,0,2),':','Color',[57 106 177]./255,'LineWidth',2)
lgd_obs = legend({'EKI','Single Subsampling'},'Location','northeast');
title(lgd_obs,'$||\Phi(\bar{u}(t))-\Phi(u_{Opt})||$','interpreter', 'latex','FontSize',20)
xlabel('T')
xlim([jumptimes(2) 1e5])
title('Mean absolute error + standard deviation of functionals', 'interpreter', 'latex')

fig5 = figure(5);
hold on
grid on
set(gca, 'YScale', 'log')
set(gca, 'XScale', 'log')
plot(tspan_alt,mean(est_err_sol,2),'Color',[204 37 41]./255,'LineWidth',2.5)
plot(jumptimes,mean(est_err_ss_param,2),'Color',[57 106 177]./255,'LineWidth',2.5)
%plot(tspan_alt,mean(est_err_sol,2)+std(est_err_sol,0,2),':','Color',[204 37 41]./255,'LineWidth',2)
%plot(tspan_alt,mean(est_err_sol,2)-std(est_err_sol,0,2),':','Color',[204 37 41]./255,'LineWidth',2)
%plot(jumptimes,mean(est_err_ss_param,2)+std(est_err_ss_param,0,2),':','Color',[57 106 177]./255,'LineWidth',2)
%plot(jumptimes,mean(est_err_ss_param,2)-std(est_err_ss_param,0,2),':','Color',[57 106 177]./255,'LineWidth',2)
lgd = legend({'EKI','Single Subsampling'},'Location','northeast');
title(lgd,'$||\bar{u}(t)-u_{Opt}||$','interpreter', 'latex','FontSize',15)
xlabel('T')
xlim([jumptimes(2) 1e5])
title('Mean absolute error $\pm$ standard deviation of computed solutions','interpreter', 'latex')

fig6 = figure(6);
hold on
grid on
set(gca, 'YScale', 'log')
set(gca, 'XScale', 'log')
plot(tspan_alt,ek_eki,'LineWidth',2)
xlabel('T')
xlim([tspan_alt(1) 1e5])
title('Ensemble Collapse EKI')

fig7 = figure(7);
hold on
grid on
set(gca, 'YScale', 'log')
set(gca, 'XScale', 'log')
plot(jumptimes,ek_ss,'LineWidth',2)
xlabel('T')
xlim([jumptimes(1) 1e5])
title('Ensemble Collapse Single Subsampling')

if 1==1
load(sprintf('NumericsNonLin/output%d.mat', rep));
res_end_single_sub_mean=mean(y(:,:,end),2);
res_end_mean=mean(x(:,:,end),2);

U = reshape(res_end_mean,[I-1 I-1]);
U_subs = reshape(res_end_single_sub_mean,[I-1 I-1]);
%U_ref = reshape(reg_data_missfit(:,32),[I-1 I-1]);
U_ref = reshape(z,[I-1 I-1]);

% plotting groundtruth
figure(5)
clf(5)
subplot(1,3,1)
surf(S1,S2,U_ref);%colorbar; 
colormap('cool');
shading interp;
view(2);
colormap Jet;
axis square
title('Optimiser Solution')

subplot(1,3,2)
surf(S1,S2,U);%colorbar; 
colormap('cool');
shading interp;
view(2);
colormap Jet;
axis square
title('EKI')

subplot(1,3,3)
surf(S1,S2,U_subs);%colorbar; 
colormap('cool');
shading interp;
view(2);
colormap Jet;
axis square
title('Single subsampling')
cb=colorbar('Location','east');
cb.Position = cb.Position+[.07 -0.023 0 0.04];


%Commands to save images

%file2 = sprintf('comp_solutions_param_mean_pmsd.eps');
%print('-depsc',file2)


end

%Function to save in parfor loops
function parsave(fname, x,y,z,v)
  save(fname, 'x', 'y', 'z','v')
end


