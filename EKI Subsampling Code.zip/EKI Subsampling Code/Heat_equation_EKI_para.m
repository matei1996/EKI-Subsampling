%Apply EKI/Subsampling for Heat equation; we consider here EKI for the
%parameters

 
% Heat equation example

clearvars;

% Fixed paramters for heat equation code
% timestepping/finite differences parameters

%!!! Script 'gen_heat_EKI_params.m' needs to be executed first!!!

% Load parameters for Heat equation and for initialisation of the EKI
load('EKI_Heat_equation_params.mat');



%Preallocation of different error values computed
est_err=zeros(length(tspan_alt),rep);
est_err_sol=zeros(length(tspan_alt),rep);
est_err_sol_tikho=zeros(length(tspan_alt),rep);
est_err_ss=zeros(length(jumptimes_ss),rep);
est_err_ss_tikho=zeros(length(jumptimes_ss),rep);
est_err_bs=zeros(length(jumptimes_bs),rep);
est_err_bs_param=zeros(length(jumptimes_bs),rep);


%Adapted data due to working in subspace (y-\tilde A *\theta^\perp)
y_adap=zeros(size(y,1),rep);


parfor i=1:rep
    
u_0=U*sqrt(V)*normrnd(0,10,N_KL,J); %Compute initial ensemble
u_0_bar=mean(u_0,2);
e_0=u_0-u_0_bar; %center particles
[~,basiccol]=rref(e_0); %compute linear independent particles
E_0=e_0(:,basiccol); %Construct basis


%Projetion operator onto subspace
P_E=E_0*((E_0.'*E_0)\(E_0.')); 
u_sub_orth=u_0_bar-P_E*u_0_bar; %\theta^perp

% %Tikhonov Solution
y_adap(:,i)=u_res-A*u_sub_orth; %Shift data
test=y_adap(:,i); %is needed due to parallel computing

%Construct regularised variables
A_regul=[A;sqrt(beta)*eye(d)];
y_regul=[u_res;zeros(d,1)];
y_regul_adap=y_regul-A_regul*u_sub_orth;
Gamma_reg=blkdiag(Gamma,C_0);

%Tikhonov solution of coefficients
c_regul=((A_regul*E_0)'*(Gamma_reg\(A_regul*E_0)))\(A_regul*E_0)'*(Gamma_reg\y_regul_adap);


%Tikhonov solution of parameters
reg_data_missfit=E_0*c_regul+u_sub_orth;


%Starting values for ODE solvers
U_single_sub=zeros(d,J,length(jumptimes_ss));
U_single_sub(:,:,1)=u_0;

U_batch_sub=zeros(d,J,length(jumptimes_bs));
U_batch_sub(:,:,1)=u_0;


tic;
for j=1:(length(jumptimes_ss)-1)

%Solve ode over time intervals given by jumptimes for SS

u_start=U_single_sub(:,:,j);
tspan=[jumptimes_ss(j),(jumptimes_ss(j)+jumptimes_ss(j+1))/2,jumptimes_ss(j+1)];

%Construct Data and forward Operator for corresponding time interval
start=(batch_ss(j)-1)*index+1;
last=batch_ss(j)*index;
G_sample = A(start:last,:);
Gamma_sample=Gamma(start:last,start:last);

%y_sample=test(start:last);
y_sample=y(start:last);

%Solve ODE and save endpoint as starting values for next iteration

[time,U_sub]=ode45(@(t,U) ode_right_side(t,U,G_sample,d,J,y_sample,Gamma_sample,alpha,beta,eye(d),N_sub),tspan,u_start(:),opts);
U_sub=reshape(U_sub.',d,J,[]);
U_single_sub(:,:,j+1)=U_sub(:,:,end);


end
fprintf(' Single Subsampling: ')
toc;

tic;
for j=1:(length(jumptimes_bs)-1)
%Batch subsampling needs a different Operator for each particle
%Compte forwardoperators as a compact system

G_comp=zeros(J*index,J*d);
y_comp=zeros(J*index,1);
Gamma_comp=zeros(J*index,J*index);
batch=batch_bs(j,:);
for cons=1:J
    start=(batch(cons)-1)*index+1;
    last=batch(cons)*index;
    G_comp((cons-1)*index+1:cons*index,(cons-1)*d+1:cons*d)=A(start:last,:);
    Gamma_comp((cons-1)*index+1:cons*index,(cons-1)*index+1:cons*index)=Gamma(start:last,start:last);
    y_comp((cons-1)*index+1:cons*index,:)=y(start:last);%y_adap_coef statt test
end


%Solve ODE and save endpoint as starting values for next iteration
u_start_batch=U_batch_sub(:,:,j);
tspan=[jumptimes_bs(j),(jumptimes_bs(j)+jumptimes_bs(j+1))/2,jumptimes_bs(j+1)];
[~,U_sub]=ode45(@(t,U) ode_subsamp_single_alt_comp(t,U,G_comp,d,J,y_comp,Gamma_comp,N_sub,alpha,beta,eye(d)),tspan,u_start_batch(:),opts);

U_sub=reshape(U_sub.',d,J,[]);
U_batch_sub(:,:,j+1)=U_sub(:,:,3);
end
fprintf(' Batch Subsampling: ')
toc;

%EKI
tic;
[t(:,i),U_Eki] = ode45(@(t,U) ode_right_side(t,U,A,d,J,y,Gamma,alpha,beta,eye(d),1),tspan_alt,u_0(:),opts);
U_long=reshape(U_Eki',d,J,[]);
fprintf(' EKI: ')
toc;

parsave(sprintf('NumericsLin/Coefficients/output%d.mat', i), U_long, U_single_sub,U_batch_sub,reg_data_missfit);

end

%Define potential
G = @(u) A*u;
fun = @(u) (1/2)*norm((sqrtm(Gamma))\(G(u)-y))^2+(beta/2)*norm((sqrtm(C_0))\u)^2;

%Compute errors

for i=1:rep
load(sprintf('NumericsLin/Coefficients/output%d.mat', i));
U_long=x;
U_single_sub_par=y;
U_batch_sub_par=z;
reg_data_missfit=v;

%consider forward Operator as non-linear Operator
tikho_sub_funcval=fun(reg_data_missfit);
    
     for m=1:L
          est_err(m,i) = (fun(mean(U_long(:,:,m),2))-tikho_sub_funcval);%/norm(fval(i));
          est_err_sol_tikho(m,i)=norm(mean(U_long(:,:,m),2)-reg_data_missfit);%/norm(reg_data_missfit(:,i));
     end


     for d=1:L_sub_ss
          est_err_ss(d,i)=(fun(mean(U_single_sub_par(:,:,d),2))-tikho_sub_funcval);%/norm(fval(i));
          est_err_ss_tikho(d,i)=norm(mean(U_single_sub_par(:,:,d),2)-reg_data_missfit);%/norm(reg_data_missfit(:,i));
     end
     
     for count=1:L_sub_bs
          est_err_bs(count,i)=(fun(mean(U_batch_sub_par(:,:,count),2))-tikho_sub_funcval);%/norm(fval(i));
          est_err_bs_param(count,i)=norm(mean(U_batch_sub_par(:,:,count),2)-reg_data_missfit);%/norm(reg_data_missfit(:,i));
     end      
clearvars U_long U_single_sub_par U_batch_sub_par reg_data_missfit x y z v 
     
end
%Ensemble collapse
est_err_ek = zeros(length(tspan_alt),J,rep);
est_err_ek_sub = zeros(length(jumptimes_ss),J,rep);
est_err_ek_bsub = zeros(length(jumptimes_bs),J,rep);

for i=1:rep
load(sprintf('NumericsLin/Coefficients/output%d.mat', i));
U_long=x;
U_single_sub_par=y;
U_batch_sub_par=z;
 for m=1:L
     for j=1:J
     est_err_ek(m,j,i)=norm(U_long(:,j,m)-mean(U_long(:,:,m),2));
     end
 end


 for d=1:L_sub_ss
     for j=1:J
     est_err_ek_sub(d,j,i)=norm(U_single_sub_par(:,j,d)-mean(U_single_sub_par(:,:,d),2));
     end
 end
 
 for counter=1:L_sub_bs
     for j=1:J
     est_err_ek_bsub(counter,j,i)=norm(U_batch_sub_par(:,j,counter)-mean(U_batch_sub_par(:,:,counter),2));
     end
 end
 clearvars U_long U_single_sub_par U_batch_sub_par x y z v 

end

%Consider the mean ensemble collapse over all runs for all particles
ek_eki=mean(est_err_ek,3);
ek_ss=mean(est_err_ek_sub,3);
ek_bs=mean(est_err_ek_bsub,3);

%Plot results
% % Thelines below the first plot generate mean error +- 1 std
% % delete comment if you want them

fig5 = figure(5);
hold on
grid on
set(gca, 'YScale', 'log')
set(gca, 'XScale', 'log')
plot(tspan_alt,mean(est_err_sol_tikho,2),'Color',[204 37 41]./255,'LineWidth',2.5)
plot(jumptimes_ss,mean(est_err_ss_tikho,2),'Color',[57 106 177]./255,'LineWidth',2.5)
plot(jumptimes_bs,mean(est_err_bs_param,2),'Color',[62 150 81]./255,'LineWidth',2.5)
plot(tspan_alt,mean(est_err_sol_tikho,2)+std(est_err_sol_tikho,0,2),':','Color',[204 37 41]./255,'LineWidth',2)
plot(tspan_alt,mean(est_err_sol_tikho,2)-std(est_err_sol_tikho,0,2),':','Color',[204 37 41]./255,'LineWidth',2)
plot(jumptimes_ss,mean(est_err_ss_tikho,2)+std(est_err_ss_tikho,0,2),':','Color',[57 106 177]./255,'LineWidth',2)
plot(jumptimes_ss,mean(est_err_ss_tikho,2)-std(est_err_ss_tikho,0,2),':','Color',[57 106 177]./255,'LineWidth',2)
plot(jumptimes_bs,mean(est_err_bs_param,2)+std(est_err_bs_param,0,2),':','Color',[62 150 81]./255,'LineWidth',2)
plot(jumptimes_bs,mean(est_err_bs_param,2)-std(est_err_bs_param,0,2),':','Color',[62 150 81]./255,'LineWidth',2)
lgd = legend({'EKI','Single Subsampling','Batch Subsampling'},'Location','northeast');
title(lgd,'$||\bar{u}(t)-u_{Tikho}||$','interpreter', 'latex','FontSize',15)
xlabel('T')
xlim([tspan_alt(1) T])
%title('Mean absolute error of computed solutions')
title('Mean absolute error $\pm$ standard deviation of computed solutions','interpreter', 'latex')


fig6 = figure(6);
hold on
grid on
set(gca, 'YScale', 'log')
set(gca, 'XScale', 'log')
plot(tspan_alt,mean(est_err,2),'Color',[204 37 41]./255,'LineWidth',2.5)
plot(jumptimes_ss,mean(est_err_ss,2),'Color',[57 106 177]./255,'LineWidth',2.5)
plot(jumptimes_bs,mean(est_err_bs,2),'Color',[62 150 81]./255,'LineWidth',2.5)
plot(tspan_alt,mean(est_err,2)+std(est_err,0,2),':','Color',[204 37 41]./255,'LineWidth',2)
plot(tspan_alt,mean(est_err,2)-std(est_err,0,2),':','Color',[204 37 41]./255,'LineWidth',2)
plot(jumptimes_ss,mean(est_err_ss,2)+std(est_err_ss,0,2),':','Color',[57 106 177]./255,'LineWidth',2)
plot(jumptimes_ss,mean(est_err_ss,2)-std(est_err_ss,0,2),':','Color',[57 106 177]./255,'LineWidth',2)
plot(jumptimes_bs,mean(est_err_bs,2)+std(est_err_bs,0,2),':','Color',[62 150 81]./255,'LineWidth',2)
plot(jumptimes_bs,mean(est_err_bs,2)-std(est_err_bs,0,2),':','Color',[62 150 81]./255,'LineWidth',2)
lgd = legend({'EKI','Single Subsampling','Batch Subsampling'},'Location','northeast');
title(lgd,'$||\Phi(\bar{u}(t))-\Phi(u_{Tikho})||$','interpreter', 'latex','FontSize',20)
xlabel('T')
xlim([tspan_alt(1) T])
%title('Mean absolute error of functionals')
title('Mean absolute error $\pm$ standard deviation of functionals','interpreter', 'latex')


 
fig7 = figure(7);
hold on
grid on
set(gca, 'YScale', 'log')
set(gca, 'XScale', 'log')
plot(tspan_alt,ek_eki,'LineWidth',2)
xlabel('T')
title('Ensemble Collapse EKI')

fig8 = figure(8);
hold on
grid on
set(gca, 'YScale', 'log')
set(gca, 'XScale', 'log')
plot(jumptimes_ss,ek_ss,'LineWidth',2)
xlabel('T')
title('Ensemble Collapse Single Subsampling')

fig9 = figure(9);
hold on
grid on
set(gca, 'YScale', 'log')
set(gca, 'XScale', 'log')
plot(jumptimes_bs,ek_bs,'LineWidth',2)
xlabel('T')
title('Ensemble Collapse Batch Subsampling')

%To illustrate one specific solution choose one of the computed solutions
%we choose the last one
load(sprintf('NumericsLin/Coefficients/output%d.mat', rep));
U_long_se=x;
U_long_single_se=y;
U_long_batch_se=z;
reg_data_missfit = v;

%Plot solution at different times
t1_eki=find(tspan_alt>=1);
t1_eki=t1_eki(1);
t2_eki=find(jumptimes_ss>=1);
t2_eki=t2_eki(1);
t3_eki=find(jumptimes_bs>=1);
t3_eki=t3_eki(1);


%Determine if you want to illustrate the result at the end or at a
%specified time

f_res_end_1=U_long_se(:,:,t1_eki);
%f_res_end_1=U_long_se(:,:,end);
f_res_end_mean_1=mean(f_res_end_1,2);

f_res_end_sub_1=U_long_single_se(:,:,t2_eki);
%f_res_end_sub_1=U_long_single_se(:,:,end);
f_res_end_sub_mean_1=mean(f_res_end_sub_1,2);

f_res_end_sub_single_1=U_long_batch_se(:,:,t3_eki);
%f_res_end_sub_single_1=U_long_batch_se(:,:,end);
f_res_end_sub_single_mean_1=mean(f_res_end_sub_single_1,2);

f10=figure;
hold on
grid on
plot(x_h,reg_data_missfit,'Color',[107 76 154]./255,'LineWidth',2)
plot(x_h,f_res_end_mean_1,'Color',[204 37 41]./255,'LineWidth',2)
plot(x_h,f_res_end_sub_mean_1,'Color',[57 106 177]./255,'LineWidth',2)
plot(x_h,f_res_end_sub_single_mean_1,'Color',[62 150 81]./255,'LineWidth',2)
legend({'Tikhonov solution','EKI','EKI Single Sub','EKI Batch Sub'},'location','northeast')
xlabel('Spatial points')
ylabel('forcing','rotation',0,'HorizontalAlignment','right')
title('Estimated forcing at T=10000000')

%Command to save images

%file1 = sprintf('compare_comp_sol_HeatEKi_10000000.eps');
%print('-depsc',file1)

 clearvars U_long U_single_sub_par U_batch_sub_par x y z v 




function parsave(fname, x,y,z,v)
  save(fname, 'x', 'y', 'z', 'v')
end
