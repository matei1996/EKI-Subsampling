%Script to solve Heat equation as well as to initialize EKI/Subsampling

clearvars;

dt = 0.05; % time stepsize
T = 0.3; % time horizon
h = 0.01; % spatial stepsize


% Random field
x = h:h:1-h; %spatial points
Lsc = 0.1; % Length scale parameter/correlation length
N_KL = 8; % Number of terms in Karhunen-Loève expansion
ExpCov = 10*exp((-abs(x-x'))/(Lsc)); % Definition of covariance matrix
[U,V] = eigs(ExpCov,N_KL); % Eigendecomposition to compute KL expansion

% Variable parameters

time_steps = T/dt;
time_steps_copy=int32(time_steps);
N  = (1/h) -1; %(Number of discretisation points)
plot_results=0;



f_coef = U*sqrt(V)*normrnd(0,1,N_KL,1); % Forcing
u_0_pde =zeros((1/h)-1,1); % Initial condition

u_res_coef=heatequation(u_0_pde,T,h,dt,plot_results,f_coef);
u_res_coef(1,:)=[];
u_res_coef=u_res_coef';


e=ones(N,1);
Lap_mat=(1/h^2)*spdiags([e -2*e e],-1:1,N,N);

%Construct result vector from data by stacking solution for each time step
u_res_coef=u_res_coef(:);

%Construct inverse matrix
M=((speye(N)-dt/2*Lap_mat)/dt)\eye(N);


for t=1:time_steps+1
   u_res_coef(((t-1)*N+1):(t*N))=u_res_coef(((t-1)*N+1):(t*N))-((1/2)*M*Lap_mat)^t*u_0_pde;
end

%Construct result for EKI with parameters
u_res=u_res_coef;

%Construct forward operator 
A=zeros(N*time_steps_copy,N);
rec_sum=zeros(N);
for t=1:time_steps+1
    rec_sum=rec_sum+M^t*((0.5*Lap_mat)^(t-1));
    A(((t-1)*N+1):(t*N),:)=rec_sum;
end


%Initialize parameters for EKI
G = @(u) A*u;

% Inital guess
J=5; %Ensemble size
T=1; %Time until solution is computed
d=N; %Dimension of parameter space
Gamma=eye(length(u_res_coef)); %Covariance matrix of noise
alpha=0.01; %Variance inflation
beta=10; %Regularisation factor
interm=10; %Time until diminishing learning rate is used to compute chainging times of data
a=0.01; %Scalar for learning rate
b=10; %Scalar for learning rate
N_sub=6; %amount of subsamples

%Pertrurbed data
y=u_res_coef+0.01*max(abs(G(f_coef)))*sqrt(Gamma)*randn(length(u_res_coef),1);
index=size(y,1)/N_sub; %length of subsampled data
C_0=eye(d); %scaling matrix of regularisation \|u\|_{C_0}
rep=8; %Amount of times we conduct the experiment

%Compute changing times for single subsampling and batch subsampling

if T<=interm
    %Depending on which learning rates are used the corresponing code needs
    %to be commented 
    %[jumptimes_ss, batch_ss] = subsamplelinear(a,b,T,N_sub);
    %[jumptimes_bs, batch_bs] = subsamplelinearensemble(a,b,T,N_sub,J);
    
    [jumptimes_ss, batch_ss] = subsampleexp(a,b,T,N_sub);
    [jumptimes_bs, batch_bs] = subsampleexpensemble(a,b,T,N_sub,J);
else
    single=1; %determines if we need a different batch for each particle 
    %(batch subsampling: single=0) or the same for each
    %(single subsampling: single=1)
    
    %[jumptimes_ss, batch_ss] = subsamplelinear(a,b,interm,N_sub);
    [jumptimes_ss, batch_ss] = subsampleexp(a,b,interm,N_sub);
    [jumptimes_long_ss, batch_long_ss] = subsamplebatch(interm,T,J,N_sub,single);
    jumptimes_ss=[jumptimes_ss,jumptimes_long_ss];
    batch_ss=[batch_ss,batch_long_ss];

    single=0;
    %[jumptimes_bs, batch_bs] = subsamplelinearensemble(a,b,interm,N_sub,J);
    [jumptimes_bs, batch_bs] = subsampleexpensemble(a,b,interm,N_sub,J);
    [jumptimes_long_bs, batch_long_bs] = subsamplebatch(interm,T,J,N_sub,single);
    jumptimes_bs=[jumptimes_bs,jumptimes_long_bs];
    batch_bs=[batch_bs;batch_long_bs];
end

%Determine times on which EKI solution is evaluated by ODE solver
tspan_1=0:0.002:1;
tspan_2= 1:T/1000:T;
tspan_1(end)=[];
tspan_alt=[tspan_1,tspan_2];
t=zeros(length(tspan_alt),rep);
opts=odeset('RelTol',1e-12,'AbsTol',1e-12);%ODE solver tolerance


%Running indexes for for-loops
L=length(tspan_alt);
L_sub_ss=length(jumptimes_ss);
L_sub_bs=length(jumptimes_bs);



save('EKI_Heat_equation_params_vi.mat');