%Function for the forward operator of 2D-darcy flow, given the diffusion
%coefficient we solve the pde using the function pde

function [y] = G_darcy(s,k,F)
    [I,J] = size(s);
    I = sqrt(I);
    p = zeros(I^2,J);
    y = zeros(k^2,J);
    for j=1:J
        p_help = pde(exp(reshape(s(:,j),I,I)),F);
        p(:,j) = p_help(:);
        y(:,j) = unc_to_obs(p(:,j),k);
    end
%     p = reshape(p,[sqrt(I),sqrt(I)]);
    
end
