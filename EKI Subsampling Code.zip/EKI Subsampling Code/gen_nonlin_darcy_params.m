%Script to solve 2D nonlinear darcy problem
%as well as to initialize EKI/Subsampling


% discretization of the PDE
I = 2^4+1;
F = 10*ones(I-1,I-1); % RHS

% grid for plotting
s1=linspace(0,1,I-1);
s2=linspace(0,1,I-1);
[S1,S2]= meshgrid(s1,s2);

% parameters of covariance matrix for gaussian random field
% we work directly in KL expansion
tau = 0.01;
alpha = 2;
meanfield = 0;

I_c = 5^2; % number of coefficients
C0 = eye(I_c,I_c);

% compute KL expansion of the gaussian random field
u_kle = @(xi)kle_execute(xi,S1,S2,meanfield,alpha,tau);

% we estimate coefficients of KL expansion
% set groundtruth
coef_true = mvnrnd(zeros(I_c,1),C0,1)';
utrue = u_kle(coef_true);

U = reshape(utrue,[I-1 I-1]);

% reference solution
G_solve = @(utr) G_darcy(utr,I-1,F);
y_solution = G_solve(utrue);


% Construction of Observation matrix O
Points = 1:length(y_solution);
K = 30; %amount of observation points
O = zeros(K,length(y_solution));

for i = 1:K
    obs_point = randi([1 length(Points)],1,1);
    O(i,Points(obs_point)) = 1;
    Points(obs_point) = [];
end


% define forward model
G = @(utr) O*G_darcy(utr,I-1,F);

% compute noisefree observation
y = G(utrue);

% perturb by some noise
Gamma = 0.01*eye(K,K);
y_noise = y+Gamma^(1/2)*randn(K,1);


%Apply EKI on observation points.
%Define parameters 

d=size(utrue,1); %dimension of parameter space
k=K; %dimension of observation space
J=10; %ensemble size
beta=10; %regularisation factor
Gamma=1*eye(k); %noise matrix
N_sub=5; %amount of subsets we consider
interm=10; %time until we compute switching times according to learning rate
a=10; %parameter for learning rate
b=10; %parameter for learning rate
T=100000; %End time
index=size(y,1)/N_sub; %Dimesnion of subsamples
rep=8;% amount of runs we do
y=y_noise;


%Compute changing times for single subsampling and batch subsampling

if T<=interm
    %Depending on which learning rates are used the corresponing code needs
    %to be commented 
    [jumptimes,~] = subsamplelinear(a,b,T,N_sub);
    %[jumptimes, ] = subsampleexp(a,b,T,N_sub);
else
    single=1;
    [jumptimes, ~] = subsamplelinear(a,b,interm,N_sub);
    %[jumptimes, ~] = subsampleexp(a,b,interm,N_sub);
    [jumptimes_long, ~] = subsamplebatch(interm,T,J,N_sub,single);
    jumptimes=[jumptimes,jumptimes_long];
end

%Define forward operators for all subsets
Points = 1:length(y);
K = index;
O_sub = zeros(K,length(y),N_sub);
Gamma_sample=zeros(K,K,N_sub);
y_sample=zeros(K,N_sub);
    

for j=1:N_sub
   for i = 1:K
    obs_point = randi([1 length(Points)],1,1);
    O_sub(i,Points(obs_point),j) = 1;
    Points(obs_point) = [];
   end
   Gamma_sample(:,:,j)=O_sub(:,:,j)*Gamma*O_sub(:,:,j).';
   y_sample(:,j)= O_sub(:,:,j)*y;
end


%Determine times for ODE solver
tspan_1=0:0.02:1;
tspan_2= 1:T/1000:T;
tspan_1(end)=[];
tspan_alt=[tspan_1,tspan_2];
t=zeros(length(tspan_alt),rep);
opts=odeset('RelTol',1e-12,'AbsTol',1e-12);

%Variables that are used for evaluation in main script
L=length(tspan_alt);
L_sub=length(jumptimes);

save('EKI_Darcy_nonlin_params.mat');

% plotting groundtruth
figure(1)
clf(1)
surf(S1,S2,U);colorbar; 
colormap('cool');
shading interp;
view(2);
colormap Jet;
axis square

% plot pde solution and observation points
obs_points = O*[1:length(y_solution)]';
obs_vector = zeros(length(y_solution),1);
obs_vector(obs_points) = 1;
obs_plot_1 = S1(obs_vector==1);
obs_plot_2 = S2(obs_vector==1);

fig2 = figure(3);
clf(3)
set(fig2, 'Units', 'normalized', 'Position', [0.1, 0.5, 0.2, 0.2]);

[X,Y] = meshgrid(linspace(0,1,I-1),linspace(0,1,I-1));
surf(X,Y,reshape(y_solution,[I-1,I-1]));hold on
colorbar;
colormap('cool');
shading interp;
view(2);
colormap Jet;
%p1=plot3(obs_plot_1,obs_plot_2,ones(size(obs_plot_1)),'ko','LineWidth',2,'DisplayName','Observation points','markersize',2);
%title('PDE solution','FontSize',16,'Interpreter','latex')
%legend('show',p1,'Location','northeast');
axis square
